
extern zend_class_entry *phalcon_image_ce;

ZEPHIR_INIT_CLASS(Phalcon_Image);

